create trigger tri_game_id
  before INSERT
  on games
  for each row
  begin
	set new.game_id = NEXT_VAL('seq_game_id');
end;

