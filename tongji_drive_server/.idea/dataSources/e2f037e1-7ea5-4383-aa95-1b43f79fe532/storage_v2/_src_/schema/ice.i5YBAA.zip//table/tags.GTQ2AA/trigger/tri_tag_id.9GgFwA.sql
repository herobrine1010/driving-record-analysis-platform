create trigger tri_tag_id
  before INSERT
  on tags
  for each row
  begin
	set new.tag_id = NEXT_VAL('seq_tag_id');
end;

