create function NEXT_VAL(sequence_name varchar(64))
  returns bigint
  BEGIN
    UPDATE sequences t, (SELECT @current_val:=`value` FROM sequences t2 WHERE t2.sequence_name=sequence_name) t3 SET t.value = t.value + 1 WHERE t.sequence_name =sequence_name AND @current_val=t.value;
    RETURN @current_val+1;
END;

