create trigger tri_consoles_id
  before INSERT
  on consoles
  for each row
  begin
	set new.console_id = NEXT_VAL('seq_console_id');
end;

