create trigger tri_cate_id
  before INSERT
  on categories
  for each row
  begin
	set new.cate_id = NEXT_VAL('seq_cate_id');
end;

