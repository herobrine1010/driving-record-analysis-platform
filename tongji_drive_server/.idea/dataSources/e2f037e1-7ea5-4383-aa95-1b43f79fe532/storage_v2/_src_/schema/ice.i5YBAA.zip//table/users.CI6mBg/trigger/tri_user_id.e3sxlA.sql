create trigger tri_user_id
  before INSERT
  on users
  for each row
  begin
    SET new.user_id = NEXT_VAL('seq_user_id');
end;

