create trigger tri_review_id
  before INSERT
  on reviews
  for each row
  begin
	set new.review_id = NEXT_VAL('seq_review_id');
end;

