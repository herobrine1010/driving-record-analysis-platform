create trigger tri_publisher_id
  before INSERT
  on publishers
  for each row
  begin
	set new.publisher_id = NEXT_VAL('seq_publisher_id');
end;

