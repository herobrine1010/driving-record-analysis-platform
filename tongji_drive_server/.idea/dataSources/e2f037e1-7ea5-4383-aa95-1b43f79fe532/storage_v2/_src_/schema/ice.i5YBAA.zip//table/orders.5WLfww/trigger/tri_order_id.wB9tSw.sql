create trigger tri_order_id
  before INSERT
  on orders
  for each row
  begin
	set new.order_id = NEXT_VAL('seq_order_id');
end;

